import typer
from rich import print
from .pipeline import transcribe_pipeline, diarize_pipeline
from .config import settings

app = typer.Typer(add_completion=False, help="GexAI CLI: audio → text and more")

@app.command()
def transcribe(
    path: str = typer.Argument(..., help="Path to audio or video file"),
    language: str = typer.Option("es", "-l", "--language", help="Language code (ISO 639‑1)"),
    model: str = typer.Option(settings.whisper_model, "-m", "--model", help="Whisper model name"),
):
    """Transcribe an audio or video file using OpenAI Whisper."""
    texto = transcribe_pipeline(path, language=language, model=model)
    print(texto)

@app.command()
def diarize(
    path: str = typer.Argument(..., help="Path to WAV file to diarize"),
    output_dir: str = typer.Option("out/", help="Where to save audio segments and TXT"),
):
    """Separate speakers using pyannote."""
    diarize_pipeline(path, output_dir)

if __name__ == "__main__":
    app()
